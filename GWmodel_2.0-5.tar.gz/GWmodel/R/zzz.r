.onAttach <- function(lib, pkg) {
	packageStartupMessage("Welcome to GWmodel version 2.0-4.\n Note: This verision has been re-built with RcppArmadillo to improve its performance.\n", appendLF = FALSE)
  }